public class Eleitor{
    
    public int tituloEleitoral;
    public String nomeEleitor;
    public int zonaEleitoral;
    public int secao;
    public boolean present;

}

