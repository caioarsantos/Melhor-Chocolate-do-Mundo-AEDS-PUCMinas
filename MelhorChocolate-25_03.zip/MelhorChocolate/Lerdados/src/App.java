import java.util.Scanner;
import java.io.FileReader;
import java.io.BufferedReader;


public class App {

    static Eleitor eleitor = new Eleitor();

    public static void lerDados(){

        try{
        BufferedReader buffer = new BufferedReader(new FileReader("eleitores.txt"));
        String dadosstring;
        
        while((dadosstring = buffer.readLine()) != null){
        String [] dados = dadosstring.split(";");
        eleitor.tituloEleitoral = Integer.parseInt(dados[0]);
        eleitor.nomeEleitor = dados[1];
        eleitor.zonaEleitoral = Integer.parseInt(dados[2]);
        eleitor.secao = Integer.parseInt(dados[3]);
        ShowInfo(eleitor);
        }
        buffer.close();

    }catch(Exception e){
        return;
    }
    }
    public static void ShowInfo(Eleitor eleitor){
    
        System.out.println("             Dados              ");
        System.out.println("--------------------------------");
        System.out.println("Titulo Eleitoral: "+ eleitor.tituloEleitoral);
        System.out.println("Nome:             "+ eleitor.nomeEleitor);
        System.out.println("Zona Eleitoral:   "+ eleitor.zonaEleitoral);
        System.out.println("Seção:            "+ eleitor.secao);
        System.out.println("--------------------------------");
    }
    public static void main(String[] args) throws Exception {
         
    ///Scanner sc = new Scanner(System.in);

    //String arquivoLeiturString = "eleitores.txt";

    //String dadospikas = "36;mAURICIO;sim;666";
    lerDados();
   //ShowInfo(eleitor);
    System.out.println("");
    }
}

