//import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;


public class App {

//------------------------------------------------------------------------------------------------    
//Variaveis
//------------------------------------------------------------------------------------------------

static Eleitor eleitor = new Eleitor();
static File file = new File("eleitores.txt");

//------------------------------------------------------------------------------------------------
//Mostra a informação
//------------------------------------------------------------------------------------------------
public static void ShowInfo(Eleitor eleitor){
    
    System.out.println("             Dados              ");
    System.out.println("--------------------------------");
    System.out.println("Titulo Eleitoral: "+ eleitor.tituloEleitoral);
    System.out.println("Nome:             "+ eleitor.nomeEleitor);
    System.out.println("Zona Eleitoral:   "+ eleitor.zonaEleitoral);
    System.out.println("Seção:            "+ eleitor.secao);
    System.out.println("--------------------------------");
}

//------------------------------------------------------------------------------------------------
//Lê os dados do arquivo
//------------------------------------------------------------------------------------------------
public static void lerDados(){

    try{
    FileReader fr = new FileReader(file);
      BufferedReader r = new BufferedReader(fr);
      String dadosstring;   
        while((dadosstring = r.readLine()) != null){
          String [] dados = dadosstring.split(";");
          eleitor.tituloEleitoral = Integer.parseInt(dados[0]);
          eleitor.nomeEleitor = dados[1];
          eleitor.zonaEleitoral = Integer.parseInt(dados[2]);
          eleitor.secao = Integer.parseInt(dados[3]);
          ShowInfo(eleitor);
        }
        r.close();
    }
    catch(Exception e){
      return;
    }
}
//------------------------------------------------------------------------------------------------
//Escrever dadaos
//------------------------------------------------------------------------------------------------
public static void escreverDados(int titulo, String nome, int zona, int secao){
   
try{
    FileWriter fw = new FileWriter(file);
    BufferedWriter w = new BufferedWriter(fw);
    w.write(titulo + ";" + nome + ";" + zona + ";" + secao);
    w.close();
}
catch(Exception e){
    return;
}
}
//------------------------------------------------------------------------------------------------
//Main
//------------------------------------------------------------------------------------------------
public static void main(String[] args) throws Exception {

    
    escreverDados(15, "josival", 4, 158);
    escreverDados(15, "josival", 4, 144553);

    lerDados();
    
}
}

